const message = document.querySelector('.messages');

setTimeout(() => {
    $('.messages').fadeOut('slow');
}, 3000);